using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StatistiquesDashboard.Models
{
    [Table("SERVICE")]
    public class Service
    {
        [Key]
        [Column("ID_SCE")]
        public decimal IdSce { get; set; }
        
        [Column("ID_TYPE_SCE")]
        public string? IdTypeSce { get; set; }
        
        [Column("ID_MISSION")]
        public decimal IdMission { get; set; }
        
        [Column("RESUME_SCE")]
        public string? ResumeSce { get; set; }
        
        [Column("DATE_DEBUT_SCE")]
        public DateTime? DateDebutSce { get; set; }
        
        [Column("DATE_FIN_SCE")]
        public DateTime? DateFinSce { get; set; }
        
        [Column("ID_CLASS_SCE")]
        public decimal? IdClassSce { get; set; }
        
        [Column("ID_NAT_SCE")]
        public decimal? IdNatSce { get; set; }
        
        [Column("ID_DOM_SCE")]
        public decimal? IdDomSce { get; set; }
        
        [Column("NBR_MINUTE_TOT")]
        public decimal? NbrMinuteTot { get; set; }
        
        [Column("CREATED_ON")]
        public DateTime? CreatedOn { get; set; }
        
        // Navigation properties
        [ForeignKey("IdMission")]
        public virtual Mission? Mission { get; set; }
        
        [ForeignKey("IdTypeSce")]
        public virtual TypeSce? TypeSce { get; set; }
        
        [ForeignKey("IdDomSce")]
        public virtual DomaineSce? DomaineSce { get; set; }
        
        [ForeignKey("IdNatSce")]
        public virtual NatureSce? NatureSce { get; set; }
        
        [ForeignKey("IdClassSce")]
        public virtual ClassSce? ClassSce { get; set; }
        
        public virtual ICollection<ServiceMateriel> ServiceMateriels { get; set; } = new List<ServiceMateriel>();
    }
}