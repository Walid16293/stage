using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StatistiquesDashboard.Models
{
    [Table("SERVICE_MATERIEL")]
    public class ServiceMateriel
    {
        [Key]
        [Column("ID_SERVICE_MAT")]
        public decimal IdServiceMat { get; set; }
        
        [Column("ID_SCE")]
        public decimal IdSce { get; set; }
        
        [Column("ID_TYPE_MAT")]
        public decimal IdTypeMat { get; set; }
        
        [Column("LIBL_MAT")]
        public string? LiblMat { get; set; }
        
        [Column("SERIAL_NUM__MAT")]
        public string? SerialNumMat { get; set; }
        
        [Column("ETAT_MAT")]
        public string? EtatMat { get; set; }
        
        [Column("PROPRIETAIRE")]
        public string? Proprietaire { get; set; }
        
        [Column("MARQUE_MAT")]
        public string? MarqueMat { get; set; }
        
        [Column("MODELE_MAT")]
        public string? ModeleMat { get; set; }
        
        [Column("CREATED_ON")]
        public DateTime? CreatedOn { get; set; }
        
        // Navigation properties
        [ForeignKey("IdSce")]
        public virtual Service? Service { get; set; }
    }
}