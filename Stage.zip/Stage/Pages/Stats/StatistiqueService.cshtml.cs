using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StatistiquesDashboard.Data;
using StatistiquesDashboard.Models.ViewModels;
using StatistiquesDashboard.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StatistiquesDashboard.Pages.Stats
{
    public class StatistiqueServiceModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly IStatsService _statsService;

        public ResultatStatistiquesParService Resultat { get; set; } = new ResultatStatistiquesParService();
        public List<StatistiqueParService> TopServices { get; set; } = new List<StatistiqueParService>();
        public List<StatistiqueParService> TopServicesByDuration { get; set; } = new List<StatistiqueParService>();
        public List<string> Domaines { get; set; } = new List<string>();

        public StatistiqueServiceModel(ApplicationDbContext context, IStatsService statsService)
        {
            _context = context;
            _statsService = statsService;
        }

        public async Task<IActionResult> OnGetAsync()
        {
            try
            {
                // Récupérer les statistiques par service
                Resultat = await _statsService.GetStatistiquesParServiceAsync();
                
                // Récupérer les top 10 services par nombre de missions
                TopServices = Resultat.StatistiquesParService
                    .OrderByDescending(s => s.NombreMissions)
                    .Take(10)
                    .ToList();
                
                // Récupérer les top 10 services par durée totale
                TopServicesByDuration = Resultat.StatistiquesParService
                    .OrderByDescending(s => s.DureeTotaleMinutes)
                    .Take(10)
                    .ToList();
                
                // Récupérer la liste des domaines pour le filtre
                Domaines = await _context.DomainesService
                    .Select(d => d.LibaDomSce)
                    .OrderBy(l => l)
                    .ToListAsync();
                
                return Page();
            }
            catch (Exception ex)
            {
                // Gérer l'erreur (par exemple, en l'enregistrant) et afficher un message convivial
                ModelState.AddModelError(string.Empty, "Une erreur s'est produite lors du chargement des statistiques par service.");
                Console.WriteLine($"Erreur: {ex.Message}");
                
                // Initialiser un résultat vide pour éviter les exceptions null
                Resultat = new ResultatStatistiquesParService();
                return Page();
            }
        }

        // Cette méthode peut être utilisée pour récupérer les détails d'un service spécifique via AJAX
        public async Task<IActionResult> OnGetDetailServiceAsync(int idService)
        {
            try
            {
                var detailsService = await _statsService.GetDetailsService(idService);
                return new JsonResult(detailsService);
            }
            catch (Exception ex)
            {
                return new JsonResult(new { error = ex.Message });
            }
        }
    }
}