using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace StatistiquesDashboard.Filters
{
    public class SessionAuthorizationAttribute : TypeFilterAttribute
    {
        public SessionAuthorizationAttribute() : base(typeof(SessionAuthorizationFilter))
        {
        }

        private class SessionAuthorizationFilter : IAuthorizationFilter
        {
            private readonly ILogger<SessionAuthorizationFilter> _logger;

            public SessionAuthorizationFilter(ILogger<SessionAuthorizationFilter> logger)
            {
                _logger = logger;
            }

            public void OnAuthorization(AuthorizationFilterContext context)
            {
                _logger.LogInformation("Vérification de l'autorisation via session");
                
                var userId = context.HttpContext.Session.GetString("UserId");
                var privilege = context.HttpContext.Session.GetString("Privilege");
                
                if (string.IsNullOrEmpty(userId))
                {
                    _logger.LogWarning("Utilisateur non authentifié, redirection vers la page de connexion");
                    context.Result = new RedirectToActionResult("Login", "Account", null);
                    return;
                }
                
                if (privilege != "accepter")
                {
                    _logger.LogWarning("Utilisateur sans privilège suffisant: {Privilege}", privilege);
                    context.Result = new RedirectToActionResult("AccessDenied", "Account", null);
                    return;
                }
                
                _logger.LogInformation("Autorisation accordée pour l'utilisateur avec ID: {UserId}", userId);
            }
        }
    }
}