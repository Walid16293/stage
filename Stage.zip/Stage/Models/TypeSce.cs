using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StatistiquesDashboard.Models
{
    [Table("TYPE_SCE")]
    public class TypeSce
    {
        [Key]
        [Column("ID_TYPE_SCE")]
        public string IdTypeSce { get; set; } = string.Empty;
        
        [Column("ID_CLASS_SCE")]
        public decimal IdClassSce { get; set; }
        
        [Column("LIBA_TYPE_SCE")]
        public string? LibaTypeSce { get; set; }
        
        [Column("LIBL_TYPE_SCE")]
        public string? LiblTypeSce { get; set; }
        
        [Column("LIB_COMPLETE")]
        public string? LibComplete { get; set; }
        
        // Navigation properties
        [ForeignKey("IdClassSce")]
        public virtual ClassSce? ClassSce { get; set; }
        
        public virtual ICollection<Service> Services { get; set; } = new List<Service>();
    }
}