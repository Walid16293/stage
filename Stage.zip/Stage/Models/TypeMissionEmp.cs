using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StatistiquesDashboard.Models
{
    [Table("TYPE_MISSION_EMP")]
    public class TypeMissionEmp
    {
        [Key]
        [Column("ID_TYPE_MISSION")]
        public decimal IdTypeMission { get; set; }
        
        [Column("LIBA_TYPE_MISSION")]
        public string? LibaTypeMission { get; set; }
        
        [Column("LIBL_TYPE_MISSION")]
        public string? LiblTypeMission { get; set; }
        
        // Navigation properties
        public virtual ICollection<MissionEmploye> MissionEmployes { get; set; } = new List<MissionEmploye>();
    }
}