using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StatistiquesDashboard.Models
{
    [Table("DOMAINE_SCE")]
    public class DomaineSce
    {
        [Key]
        [Column("ID_DOM_SCE")]
        public decimal IdDomSce { get; set; }
        
        [Column("LIBA_DOM_SCE")]
        public string? LibaDomSce { get; set; }
        
        // Navigation properties
        public virtual ICollection<Service> Services { get; set; } = new List<Service>();
        public virtual ICollection<NatureSce> NatureServices { get; set; } = new List<NatureSce>();
    }
}