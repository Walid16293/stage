using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StatistiquesDashboard.Models
{
    [Table("CLASS_SCE")]
    public class ClassSce
    {
        [Key]
        [Column("ID_CLASS_SCE")]
        public decimal IdClassSce { get; set; }
        
        [Column("ID_NAT_SCE")]
        public decimal IdNatSce { get; set; }
        
        [Column("LIBA_CLASS_SCE")]
        public string? LibaClassSce { get; set; }
        
        [Column("LIBL_CLASS_SCE")]
        public string? LiblClassSce { get; set; }
        
        [Column("LIB_COMPLETE")]
        public string? LibComplete { get; set; }
        
        // Navigation properties
        [ForeignKey("IdNatSce")]
        public virtual NatureSce? NatureSce { get; set; }
        
        public virtual ICollection<TypeSce> TypeServices { get; set; } = new List<TypeSce>();
        public virtual ICollection<Service> Services { get; set; } = new List<Service>();
    }
}