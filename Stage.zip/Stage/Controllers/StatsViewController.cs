using Microsoft.AspNetCore.Mvc;
using StatistiquesDashboard.Services;
using StatistiquesDashboard.Models.ViewModels;
using StatistiquesDashboard.Filters;

namespace StatistiquesDashboard.Controllers
{
    [SessionAuthorization]
    public class StatsViewController : Controller
    {
        private readonly IStatsService _statsService;
        private readonly ILogger<StatsViewController> _logger;

        public StatsViewController(IStatsService statsService, ILogger<StatsViewController> logger)
        {
            _statsService = statsService;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Domaines()
        {
            return View();
        }

        public IActionResult Services()
        {
            return View();
        }

        public IActionResult Types()
        {
            return View();
        }

        public IActionResult Missions()
        {
            return View();
        }

        public IActionResult Personnaliser()
        {
            // Récupérer les listes pour les filtres dynamiques
            ViewBag.Domaines = new List<dynamic>
            {
                new { Id = 1, Libelle = "Sécurité" },
                new { Id = 2, Libelle = "Patrouille" },
                new { Id = 3, Libelle = "Contrôle" },
                new { Id = 4, Libelle = "Assistance" }
            };
            
            ViewBag.TypesServices = new List<dynamic>
            {
                new { Id = "T1", Libelle = "Patrouille" },
                new { Id = "T2", Libelle = "Contrôle" },
                new { Id = "T3", Libelle = "Enquête" },
                new { Id = "T4", Libelle = "Surveillance" }
            };
            
            ViewBag.CategoriesMission = new List<dynamic>
            {
                new { Id = 1, Libelle = "Urgence" },
                new { Id = 2, Libelle = "Routine" },
                new { Id = 3, Libelle = "Planifiée" },
                new { Id = 4, Libelle = "Spéciale" }
            };
            
            return View();
        }

        public IActionResult DetailsDomaine(decimal id)
        {
            ViewBag.IdDomaine = id;
            return View();
        }

        public IActionResult DetailsService(decimal id)
        {
            ViewBag.IdService = id;
            return View();
        }

        public IActionResult DetailsType(string id)
        {
            ViewBag.IdType = id;
            return View();
        }

        public IActionResult DetailsMission(decimal id)
        {
            ViewBag.IdMission = id;
            return View();
        }
    }
}