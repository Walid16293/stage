using Microsoft.AspNetCore.Mvc;
using StatistiquesDashboard.Models.ViewModels;
using StatistiquesDashboard.Services;

namespace StatistiquesDashboard.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StatsFilterController : ControllerBase
    {
        private readonly IStatsService _statsService;
        private readonly ILogger<StatsFilterController> _logger;

        public StatsFilterController(IStatsService statsService, ILogger<StatsFilterController> logger)
        {
            _statsService = statsService;
            _logger = logger;
        }

        [HttpPost("calculer-domaine")]
        public async Task<IActionResult> CalculerStatistiquesDomaine([FromBody] FiltreDomaineStatistiques filtre)
        {
            try
            {
                var resultat = await _statsService.GetStatistiquesParDomaineAsync(filtre);
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors du calcul des statistiques par domaine");
                return StatusCode(500, "Une erreur est survenue lors du calcul des statistiques");
            }
        }

        [HttpPost("calculer-service")]
        public async Task<IActionResult> CalculerStatistiquesService([FromBody] FiltreServiceStatistiques filtre)
        {
            try
            {
                var resultat = await _statsService.GetStatistiquesParServiceAsync(filtre);
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors du calcul des statistiques par service");
                return StatusCode(500, "Une erreur est survenue lors du calcul des statistiques");
            }
        }

        [HttpPost("calculer-type")]
        public async Task<IActionResult> CalculerStatistiquesType([FromBody] FiltreStatistiques filtre)
        {
            try
            {
                var resultat = await _statsService.GetStatistiquesParTypeAsync(filtre);
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors du calcul des statistiques par type");
                return StatusCode(500, "Une erreur est survenue lors du calcul des statistiques");
            }
        }

        [HttpPost("calculer-mission")]
        public async Task<IActionResult> CalculerStatistiquesMission([FromBody] FiltreMissionStatistiques filtre)
        {
            try
            {
                var resultat = await _statsService.GetStatistiquesParMissionAsync(filtre);
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors du calcul des statistiques par mission");
                return StatusCode(500, "Une erreur est survenue lors du calcul des statistiques");
            }
        }

        [HttpGet("listes-reference")]
        public IActionResult GetListesReference()
        {
            try
            {
                // En production, ces listes seraient issues de la base de données
                var resultat = new
                {
                    Domaines = new List<object>
                    {
                        new { Id = 1, Libelle = "Sécurité" },
                        new { Id = 2, Libelle = "Patrouille" },
                        new { Id = 3, Libelle = "Contrôle" },
                        new { Id = 4, Libelle = "Assistance" },
                        new { Id = 5, Libelle = "Recherche" }
                    },
                    TypesServices = new List<object>
                    {
                        new { Id = "T1", Libelle = "Patrouille" },
                        new { Id = "T2", Libelle = "Contrôle" },
                        new { Id = "T3", Libelle = "Enquête" },
                        new { Id = "T4", Libelle = "Surveillance" },
                        new { Id = "T5", Libelle = "Assistance" }
                    },
                    CategoriesMission = new List<object>
                    {
                        new { Id = 1, Libelle = "Urgence" },
                        new { Id = 2, Libelle = "Routine" },
                        new { Id = 3, Libelle = "Planifiée" },
                        new { Id = 4, Libelle = "Spéciale" },
                        new { Id = 5, Libelle = "Formation" }
                    },
                    ClassesServices = new List<object>
                    {
                        new { Id = 1, Libelle = "Classe A" },
                        new { Id = 2, Libelle = "Classe B" },
                        new { Id = 3, Libelle = "Classe C" }
                    },
                    NaturesServices = new List<object>
                    {
                        new { Id = 1, Libelle = "Nature 1" },
                        new { Id = 2, Libelle = "Nature 2" },
                        new { Id = 3, Libelle = "Nature 3" }
                    }
                };

                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors de la récupération des listes de référence");
                return StatusCode(500, "Une erreur est survenue lors de la récupération des listes de référence");
            }
        }
    }
}