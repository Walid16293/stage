using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using StatistiquesDashboard.Models.ViewModels;
using StatistiquesDashboard.Services;

namespace StatistiquesDashboard.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAuthService _authService;
        private readonly ILogger<AccountController> _logger;

        public AccountController(IAuthService authService, ILogger<AccountController> logger)
        {
            _authService = authService;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
        {
            _logger.LogInformation("Tentative de connexion pour l'utilisateur: {Username}", model.Username);
            ViewData["ReturnUrl"] = returnUrl;

            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Validation du modèle échouée: {Errors}", string.Join(", ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage)));
                return View(model);
            }

            try
            {
                _logger.LogInformation("Tentative d'authentification pour l'utilisateur: {Username}", model.Username);
                var user = await _authService.AuthenticateAsync(model.Username, model.Password);

                if (user == null)
                {
                    _logger.LogWarning("Échec de l'authentification pour l'utilisateur: {Username}", model.Username);
                    ModelState.AddModelError(string.Empty, "Nom d'utilisateur ou mot de passe incorrect.");
                    return View(model);
                }

                _logger.LogInformation("Vérification des privilèges pour l'utilisateur: {Username}, ID: {UserId}", user.Username, user.IdUser);
                var hasValidPrivilege = await _authService.HasValidPrivilegeAsync(user.IdUser);
                if (!hasValidPrivilege)
                {
                    _logger.LogWarning("Privilèges insuffisants pour l'utilisateur: {Username}, Privilège: {Privilege}", user.Username, user.Privilege);
                    ModelState.AddModelError(string.Empty, "Vous n'avez pas les privilèges nécessaires pour accéder à cette application.");
                    return View(model);
                }

                try 
                {
                    _logger.LogInformation("Tentative de connexion pour l'utilisateur: {Username}", user.Username);
                    
                    // Stocker les informations de l'utilisateur dans la session au lieu d'utiliser des cookies sécurisés
                    HttpContext.Session.SetString("UserId", user.IdUser.ToString());
                    HttpContext.Session.SetString("Username", user.Username ?? string.Empty);
                    HttpContext.Session.SetString("Privilege", user.Privilege ?? string.Empty);
                    
                    _logger.LogInformation("L'utilisateur {Username} s'est connecté avec succès", user.Username);

                    if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                    {
                        _logger.LogInformation("Redirection vers URL de retour: {ReturnUrl}", returnUrl);
                        return Redirect(returnUrl);
                    }
                    else
                    {
                        _logger.LogInformation("Redirection vers StatsView/Index");
                        return RedirectToAction("Index", "StatsView");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Erreur lors de la connexion pour l'utilisateur: {Username}", user.Username);
                    ModelState.AddModelError(string.Empty, "Erreur lors de la connexion. Veuillez réessayer.");
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur pendant la connexion");
                ModelState.AddModelError(string.Empty, "Une erreur est survenue lors de la tentative de connexion. Veuillez réessayer plus tard.");
                return View(model);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Logout()
        {
            // Effacer toutes les données de session
            HttpContext.Session.Clear();
            
            return RedirectToAction("Login", "Account");
        }

        public IActionResult AccessDenied()
        {
            return View();
        }
    }
}