namespace StatistiquesDashboard.Models.ViewModels
{
    public class StatistiqueParType
    {
        public string IdType { get; set; } = string.Empty;
        public string LibelleType { get; set; } = string.Empty;
        public int NombreServices { get; set; }
        public int NombreMissions { get; set; }
        public double PourcentageTotal { get; set; }
        public Dictionary<string, int> DistributionParMois { get; set; } = new Dictionary<string, int>();
        
        // Propriétés pour les graphiques
        public List<string> LabelsGraphique => DistributionParMois.Keys.ToList();
        public List<int> DonneesGraphique => DistributionParMois.Values.ToList();
        public string CouleurPrincipale { get; set; } = "#1cc88a";
        public List<string> PaletteDeCouleurs { get; set; } = new List<string>
        {
            "#1cc88a", "#4e73df", "#36b9cc", "#f6c23e", "#e74a3b", "#858796",
            "#5a5c69", "#476adc", "#17a673", "#2c9faf", "#f5b835", "#e02d1b"
        };
    }
    
    public class ResultatStatistiquesParType
    {
        public int TotalServices { get; set; }
        public int TotalTypesServices { get; set; }
        public List<StatistiqueParType> StatistiquesParType { get; set; } = new List<StatistiqueParType>();
        
        // Propriétés pour les graphiques globaux
        public List<string> LabelsTypes => StatistiquesParType.Select(s => s.LibelleType).ToList();
        public List<int> NombreServicesParType => StatistiquesParType.Select(s => s.NombreServices).ToList();
        public List<int> NombreMissionsParType => StatistiquesParType.Select(s => s.NombreMissions).ToList();
        public List<double> PourcentagesParType => StatistiquesParType.Select(s => s.PourcentageTotal).ToList();
        public List<string> CouleursGraphique => new List<string>
        {
            "#1cc88a", "#4e73df", "#36b9cc", "#f6c23e", "#e74a3b", "#858796",
            "#5a5c69", "#476adc", "#17a673", "#2c9faf", "#f5b835", "#e02d1b"
        };
    }
}