using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using StatistiquesDashboard.Data;
using StatistiquesDashboard.Services;
using System;

var builder = WebApplication.CreateBuilder(args);

// Ajouter les services au conteneur.
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages(); // Ajout du support pour les Razor Pages

// Ajouter le service de session pour stocker les informations de l'utilisateur
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(2);
    options.Cookie.HttpOnly = false;
    options.Cookie.IsEssential = true;
    options.Cookie.SecurePolicy = CookieSecurePolicy.None;
});

// Configurer la connexion à la base de données Oracle
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseOracle(builder.Configuration.GetConnectionString("OracleConnection")));

// Enregistrer les services
builder.Services.AddScoped<IStatsService, StatsService>();
builder.Services.AddScoped<IAuthService, AuthService>();

// Configurer l'authentification par cookies (sans SSL)
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.LogoutPath = "/Account/Logout";
        options.AccessDeniedPath = "/Account/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromHours(2);
        options.Cookie.SecurePolicy = CookieSecurePolicy.None; // Désactiver la sécurité des cookies
        options.Cookie.HttpOnly = false; // Permettre l'accès aux cookies via JavaScript
        options.Cookie.SameSite = SameSiteMode.None; // Permettre les cookies cross-site
    });

var app = builder.Build();

// Configurer le pipeline de requêtes HTTP
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // Ne pas utiliser HSTS car nous sommes en HTTP uniquement
    // app.UseHsts();
}

// Désactivation de la redirection HTTPS car nous utilisons HTTP uniquement dans un réseau isolé
// app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseRouting();
app.UseSession(); // Activer l'utilisation des sessions
app.UseAuthentication();
app.UseAuthorization();

// Configuration des routes pour les contrôleurs
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

// Configuration des routes pour les Razor Pages
app.MapRazorPages();

// Démarrer le serveur sur le port 5000 et écouter sur toutes les interfaces réseau
app.Run();