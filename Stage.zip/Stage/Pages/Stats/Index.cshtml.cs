using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StatistiquesDashboard.Data;
using StatistiquesDashboard.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StatistiquesDashboard.Pages.Stats
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly IStatsService _statsService;

        public int NombreMissions { get; set; }
        public int NombreServices { get; set; }
        public int NombreDomaines { get; set; }
        public int NombreTypes { get; set; }

        public List<string> MoisLabels { get; set; } = new List<string>();
        public List<int> MissionsParMois { get; set; } = new List<int>();
        public List<string> DomainesLabels { get; set; } = new List<string>();
        public List<int> ServicesParDomaine { get; set; } = new List<int>();

        public IndexModel(ApplicationDbContext context, IStatsService statsService)
        {
            _context = context;
            _statsService = statsService;
        }

        public async Task OnGetAsync()
        {
            try
            {
                // Récupérer les comptages de base
                NombreMissions = await _context.Missions.CountAsync();
                NombreServices = await _context.Services.CountAsync();
                NombreDomaines = await _context.DomainesService.CountAsync();
                NombreTypes = await _context.TypesService.CountAsync();

                // Récupérer les statistiques pour les graphiques
                var statutsMissionParMois = await _statsService.GetMissionsParMoisAsync();
                var statsServicesParDomaine = await _statsService.GetServicesParDomaineAsync();

                // Préparer les données pour le graphique des missions par mois
                foreach (var item in statutsMissionParMois.OrderBy(m => m.Key))
                {
                    MoisLabels.Add(item.Key);
                    MissionsParMois.Add(item.Value);
                }

                // Préparer les données pour le graphique des services par domaine
                foreach (var item in statsServicesParDomaine.OrderByDescending(m => m.Value).Take(10))
                {
                    DomainesLabels.Add(item.Key);
                    ServicesParDomaine.Add(item.Value);
                }
            }
            catch (Exception ex)
            {
                // Gérer l'erreur (par exemple, en l'enregistrant) et afficher un message convivial
                ModelState.AddModelError(string.Empty, "Une erreur s'est produite lors du chargement des statistiques.");
                Console.WriteLine($"Erreur: {ex.Message}");
                
                // Initialiser des valeurs par défaut en cas d'erreur
                NombreMissions = 0;
                NombreServices = 0;
                NombreDomaines = 0;
                NombreTypes = 0;
            }
        }
    }
}