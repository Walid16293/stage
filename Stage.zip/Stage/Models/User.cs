using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StatistiquesDashboard.Models
{
    [Table("USERS")]
    public class User
    {
        [Key]
        [Column("ID_USER")]
        public decimal IdUser { get; set; }
        
        [Column("USERNAME")]
        public string? Username { get; set; }
        
        [Column("PASSWORD")]
        public string? Password { get; set; }
        
        [Column("EMAIL")]
        public string? Email { get; set; }
        
        [Column("PRIVILEGE")]
        public string? Privilege { get; set; }
        
        [Column("CREATED_ON")]
        public DateTime? CreatedOn { get; set; }
        
        [Column("CREATED_BY")]
        public string? CreatedBy { get; set; }
        
        [Column("UPDATED_ON")]
        public DateTime? UpdatedOn { get; set; }
        
        [Column("UPDATED_BY")]
        public string? UpdatedBy { get; set; }
    }
}