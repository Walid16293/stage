using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StatistiquesDashboard.Models
{
    [Table("NATURE_SCE")]
    public class NatureSce
    {
        [Key]
        [Column("ID_NAT_SCE")]
        public decimal IdNatSce { get; set; }
        
        [Column("LIBA_NAT_SCE")]
        public string LibaNatSce { get; set; } = string.Empty;
        
        [Column("ID_DOM_SCE")]
        public decimal IdDomSce { get; set; }
        
        // Navigation properties
        [ForeignKey("IdDomSce")]
        public virtual DomaineSce? DomaineSce { get; set; }
        
        public virtual ICollection<ClassSce> ClassServices { get; set; } = new List<ClassSce>();
        public virtual ICollection<Service> Services { get; set; } = new List<Service>();
    }
}