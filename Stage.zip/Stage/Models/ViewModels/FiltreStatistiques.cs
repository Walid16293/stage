using System.ComponentModel.DataAnnotations;

namespace StatistiquesDashboard.Models.ViewModels
{
    public class FiltreStatistiques
    {
        // Filtres temporels
        public DateTime? DateDebut { get; set; }
        public DateTime? DateFin { get; set; }
        
        // Filtres par entité
        public decimal? IdDomaine { get; set; }
        public decimal? IdClasseService { get; set; }
        public decimal? IdNatureService { get; set; }
        public string? IdTypeService { get; set; }
        public decimal? IdCategorieMission { get; set; }
        
        // Filtre par statut
        public bool? MissionsTerminees { get; set; }
        public bool? MissionsEnCours { get; set; }
        
        // Groupement et agrégation
        [Range(1, 12)]
        public int? PeriodeMois { get; set; } // Nombre de mois à considérer (par défaut 12)
        
        [Range(1, 4)]
        public int? GroupementTemporel { get; set; } // 1=Jour, 2=Semaine, 3=Mois, 4=Année
        
        // Filtres de limite
        [Range(1, 100)]
        public int? NombreResultats { get; set; } = 10; // Nombre de résultats à retourner
        
        // Tri
        public string? ChampTri { get; set; } // Champ pour le tri
        public bool TriDescendant { get; set; } = true; // Tri descendant par défaut
    }
    
    public class FiltreDomaineStatistiques : FiltreStatistiques
    {
        // Filtres spécifiques aux domaines
        public int? NombreMinimumServices { get; set; }
    }
    
    public class FiltreServiceStatistiques : FiltreStatistiques
    {
        // Filtres spécifiques aux services
        public int? DureeMinimale { get; set; } // Durée minimale en minutes
        public int? DureeMaximale { get; set; } // Durée maximale en minutes
    }
    
    public class FiltreMissionStatistiques : FiltreStatistiques
    {
        // Filtres spécifiques aux missions
        public int? NombreMinimumEmployes { get; set; }
        public int? NombreMinimumVehicules { get; set; }
    }
}