using Microsoft.EntityFrameworkCore;
using StatistiquesDashboard.Data;
using StatistiquesDashboard.Models;
using System.Threading.Tasks;

namespace StatistiquesDashboard.Services
{
    public interface IAuthService
    {
        Task<User?> AuthenticateAsync(string username, string password);
        Task<bool> HasValidPrivilegeAsync(decimal userId);
    }

    public class AuthService : IAuthService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<AuthService> _logger;

        public AuthService(ApplicationDbContext context, ILogger<AuthService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<User?> AuthenticateAsync(string username, string password)
        {
            try
            {
                _logger.LogInformation("Recherche de l'utilisateur dans la base de données: {Username}", username);
                
                // Vérifier si la table Users existe et a des données
                try
                {
                    var usersExist = await _context.Users.AnyAsync();
                    _logger.LogInformation("La table Users contient-elle des données? {UsersExist}", usersExist);
                    
                    if (usersExist)
                    {
                        // D'abord, recherchez l'utilisateur uniquement par nom d'utilisateur pour voir s'il existe
                        var userByName = await _context.Users
                            .FirstOrDefaultAsync(u => u.Username == username);
                        
                        if (userByName == null)
                        {
                            _logger.LogWarning("Utilisateur non trouvé avec le nom d'utilisateur: {Username}", username);
                            // Si nous ne trouvons pas l'utilisateur, mais que nous avons un accès à la base de données,
                            // cela signifie que l'utilisateur n'existe vraiment pas
                            return null;
                        }
                        
                        _logger.LogInformation("Utilisateur trouvé: {Username}, vérification du mot de passe", username);
                        
                        // Ensuite, vérifiez si le mot de passe correspond
                        var user = await _context.Users
                            .FirstOrDefaultAsync(u => u.Username == username && u.Password == password);
                        
                        if (user == null)
                        {
                            _logger.LogWarning("Mot de passe incorrect pour l'utilisateur: {Username}", username);
                            return null;
                        }
                        
                        _logger.LogInformation("Authentification réussie pour l'utilisateur: {Username}", username);
                        return user;
                    }
                }
                catch (Exception dbEx)
                {
                    _logger.LogWarning(dbEx, "Impossible d'accéder à la table Users. Utilisation d'un utilisateur temporaire pour le développement.");
                    // Ne pas lancer l'exception, continuer avec l'utilisateur de développement ci-dessous
                }
                
                // Mode développement / secours : si la table n'existe pas encore ou si nous ne pouvons pas y accéder,
                // nous créons un utilisateur temporaire pour les tests
                if (username == "admin" && password == "admin123")
                {
                    _logger.LogWarning("Utilisation d'un utilisateur de développement pour {Username}", username);
                    return new User
                    {
                        IdUser = 1,
                        Username = "admin",
                        Password = "admin123",
                        Email = "admin@example.com",
                        Privilege = "accepter",
                        CreatedOn = DateTime.Now,
                        CreatedBy = "system"
                    };
                }
                
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors de l'authentification pour l'utilisateur: {Username}", username);
                return null;
            }
        }

        public async Task<bool> HasValidPrivilegeAsync(decimal userId)
        {
            try
            {
                _logger.LogInformation("Vérification des privilèges pour l'utilisateur avec ID: {UserId}", userId);
                
                var user = await _context.Users
                    .FirstOrDefaultAsync(u => u.IdUser == userId);
                
                if (user == null)
                {
                    _logger.LogWarning("Utilisateur non trouvé avec l'ID: {UserId}", userId);
                    return false;
                }
                
                var hasValidPrivilege = user.Privilege == "accepter";
                _logger.LogInformation("Utilisateur {UserId} a le privilège: {Privilege}, valide: {HasValidPrivilege}", 
                    userId, user.Privilege, hasValidPrivilege);
                
                return hasValidPrivilege;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors de la vérification des privilèges pour l'utilisateur: {UserId}", userId);
                return false;
            }
        }
    }
}