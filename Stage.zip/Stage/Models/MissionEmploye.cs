using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StatistiquesDashboard.Models
{
    [Table("MISSION_EMPLOYE")]
    public class MissionEmploye
    {
        [Key]
        [Column("ID_EMP_MISS")]
        public decimal IdEmpMiss { get; set; }
        
        [Column("ID_MISSION")]
        public decimal? IdMission { get; set; }
        
        [Column("ID_EMP")]
        public decimal? IdEmp { get; set; }
        
        [Column("ID_TYPE_MISSION")]
        public decimal? IdTypeMission { get; set; }
        
        [Column("NOM_EMP")]
        public string? NomEmp { get; set; }
        
        [Column("PRENOM_EMP")]
        public string? PrenomEmp { get; set; }
        
        [Column("GRADE_EMP")]
        public string? GradeEmp { get; set; }
        
        [Column("MAT_EMP")]
        public string? MatEmp { get; set; }
        
        [Column("CREATED_ON")]
        public DateTime? CreatedOn { get; set; }
        
        // Navigation properties
        [ForeignKey("IdMission")]
        public virtual Mission? Mission { get; set; }
        
        [ForeignKey("IdTypeMission")]
        public virtual TypeMissionEmp? TypeMissionEmp { get; set; }
    }
}