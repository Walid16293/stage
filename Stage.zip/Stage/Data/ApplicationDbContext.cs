using Microsoft.EntityFrameworkCore;
using StatistiquesDashboard.Models;

namespace StatistiquesDashboard.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<CategorieMission> CategoriesMission { get; set; }
        public DbSet<Mission> Missions { get; set; }
        public DbSet<Service> Services { get; set; }
        public DbSet<DomaineSce> DomainesService { get; set; }
        public DbSet<NatureSce> NaturesService { get; set; }
        public DbSet<ClassSce> ClassesService { get; set; }
        public DbSet<TypeSce> TypesService { get; set; }
        public DbSet<MissionEmploye> MissionEmployes { get; set; }
        public DbSet<MissionVehicule> MissionVehicules { get; set; }
        public DbSet<TypeMissionEmp> TypesMissionEmploye { get; set; }
        public DbSet<ServiceMateriel> ServiceMateriels { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configuration spécifique pour Oracle
            modelBuilder.HasDefaultSchema("\"C##TEST_USER\"");

            // Configuration des relations
            modelBuilder.Entity<Mission>()
                .HasOne(m => m.CategorieMission)
                .WithMany(c => c.Missions)
                .HasForeignKey(m => m.IdCategMiss)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Service>()
                .HasOne(s => s.Mission)
                .WithMany(m => m.Services)
                .HasForeignKey(s => s.IdMission)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Service>()
                .HasOne(s => s.DomaineSce)
                .WithMany(d => d.Services)
                .HasForeignKey(s => s.IdDomSce)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Service>()
                .HasOne(s => s.NatureSce)
                .WithMany(n => n.Services)
                .HasForeignKey(s => s.IdNatSce)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Service>()
                .HasOne(s => s.ClassSce)
                .WithMany(c => c.Services)
                .HasForeignKey(s => s.IdClassSce)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Service>()
                .HasOne(s => s.TypeSce)
                .WithMany(t => t.Services)
                .HasForeignKey(s => s.IdTypeSce)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<MissionEmploye>()
                .HasOne(me => me.Mission)
                .WithMany(m => m.MissionEmployes)
                .HasForeignKey(me => me.IdMission)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<MissionVehicule>()
                .HasOne(mv => mv.Mission)
                .WithMany(m => m.MissionVehicules)
                .HasForeignKey(mv => mv.IdMission)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<ServiceMateriel>()
                .HasOne(sm => sm.Service)
                .WithMany(s => s.ServiceMateriels)
                .HasForeignKey(sm => sm.IdSce)
                .OnDelete(DeleteBehavior.Restrict);

            base.OnModelCreating(modelBuilder);
        }
    }
}