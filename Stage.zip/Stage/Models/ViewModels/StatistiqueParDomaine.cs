namespace StatistiquesDashboard.Models.ViewModels
{
    public class StatistiqueParDomaine
    {
        public decimal IdDomaine { get; set; }
        public string LibelleDomaine { get; set; } = string.Empty;
        public int NombreServices { get; set; }
        public int NombreMissions { get; set; }
        public double PourcentageTotal { get; set; }
        public Dictionary<string, int> DistributionParMois { get; set; } = new Dictionary<string, int>();
        
        // Propriétés pour les graphiques
        public List<string> LabelsGraphique => DistributionParMois.Keys.ToList();
        public List<int> DonneesGraphique => DistributionParMois.Values.ToList();
        public string CouleurPrincipale { get; set; } = "#4e73df";
        public List<string> PaletteDeCouleurs { get; set; } = new List<string>
        {
            "#4e73df", "#1cc88a", "#36b9cc", "#f6c23e", "#e74a3b", "#858796",
            "#5a5c69", "#476adc", "#17a673", "#2c9faf", "#f5b835", "#e02d1b"
        };
    }
    
    public class ResultatStatistiquesParDomaine
    {
        public int TotalServices { get; set; }
        public int TotalMissions { get; set; }
        public List<StatistiqueParDomaine> StatistiquesParDomaine { get; set; } = new List<StatistiqueParDomaine>();
        
        // Propriétés pour les graphiques globaux
        public List<string> LabelsDomaines => StatistiquesParDomaine.Select(s => s.LibelleDomaine).ToList();
        public List<int> NombreServicesParDomaine => StatistiquesParDomaine.Select(s => s.NombreServices).ToList();
        public List<int> NombreMissionsParDomaine => StatistiquesParDomaine.Select(s => s.NombreMissions).ToList();
        public List<double> PourcentagesParDomaine => StatistiquesParDomaine.Select(s => s.PourcentageTotal).ToList();
        public List<string> CouleursGraphique => new List<string>
        {
            "#4e73df", "#1cc88a", "#36b9cc", "#f6c23e", "#e74a3b", "#858796",
            "#5a5c69", "#476adc", "#17a673", "#2c9faf", "#f5b835", "#e02d1b"
        };
    }
}