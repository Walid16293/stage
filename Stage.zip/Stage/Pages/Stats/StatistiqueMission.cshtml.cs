using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StatistiquesDashboard.Data;
using StatistiquesDashboard.Models.ViewModels;
using StatistiquesDashboard.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StatistiquesDashboard.Pages.Stats
{
    public class StatistiqueMissionModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly IStatsService _statsService;

        public ResultatStatistiquesParMission Resultat { get; set; } = new ResultatStatistiquesParMission();
        public List<string> Categories { get; set; } = new List<string>();
        public List<string> MoisLabels { get; set; } = new List<string>();
        public List<int> MissionsParMois { get; set; } = new List<int>();
        public List<string> CategoriesLabels { get; set; } = new List<string>();
        public List<int> MissionsParCategorie { get; set; } = new List<int>();

        public StatistiqueMissionModel(ApplicationDbContext context, IStatsService statsService)
        {
            _context = context;
            _statsService = statsService;
        }

        public async Task<IActionResult> OnGetAsync()
        {
            try
            {
                // Récupérer les statistiques par mission
                Resultat = await _statsService.GetStatistiquesParMissionAsync();
                
                // Récupérer la liste des catégories de mission pour le filtre
                Categories = await _context.CategoriesMission
                    .Select(c => c.LibaCategMiss)
                    .OrderBy(l => l)
                    .ToListAsync();
                
                // Préparer les données pour le graphique des missions par mois
                var missionsParMois = Resultat.MissionsParMois;
                foreach (var item in missionsParMois)
                {
                    MoisLabels.Add(item.Key);
                    MissionsParMois.Add(item.Value);
                }
                
                // Récupérer les données pour le graphique des missions par catégorie
                var stats = await _statsService.GetMissionsParCategorieAsync();
                foreach (var item in stats)
                {
                    CategoriesLabels.Add(item.Key);
                    MissionsParCategorie.Add(item.Value);
                }
                
                return Page();
            }
            catch (Exception ex)
            {
                // Gérer l'erreur (par exemple, en l'enregistrant) et afficher un message convivial
                ModelState.AddModelError(string.Empty, "Une erreur s'est produite lors du chargement des statistiques par mission.");
                Console.WriteLine($"Erreur: {ex.Message}");
                
                // Initialiser un résultat vide pour éviter les exceptions null
                Resultat = new ResultatStatistiquesParMission();
                return Page();
            }
        }

        // Cette méthode peut être utilisée pour récupérer les détails d'une mission spécifique via AJAX
        public async Task<IActionResult> OnGetDetailMissionAsync(int idMission)
        {
            try
            {
                var detailsMission = await _statsService.GetDetailsMission(idMission);
                return new JsonResult(detailsMission);
            }
            catch (Exception ex)
            {
                return new JsonResult(new { error = ex.Message });
            }
        }
    }
}