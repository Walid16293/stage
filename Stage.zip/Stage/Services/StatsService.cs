using Microsoft.EntityFrameworkCore;
using StatistiquesDashboard.Data;
using StatistiquesDashboard.Models;
using StatistiquesDashboard.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace StatistiquesDashboard.Services
{
    public class StatsService : IStatsService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<StatsService> _logger;

        public StatsService(ApplicationDbContext context, ILogger<StatsService> logger)
        {
            _context = context;
            _logger = logger;
        }

        #region Statistiques générales
        public async Task<Dictionary<string, int>> GetMissionsParMoisAsync(FiltreStatistiques? filtre = null)
        {
            try
            {
                var dateDebut = DateTime.Now.AddMonths(-11);
                
                var resultat = await _context.Missions
                    .Where(m => m.DateDebutMission >= dateDebut)
                    .GroupBy(m => new { Mois = m.DateDebutMission!.Value.Month, Annee = m.DateDebutMission.Value.Year })
                    .Select(g => new
                    {
                        Periode = $"{GetNomMois(g.Key.Mois)} {g.Key.Annee}",
                        Nombre = g.Count()
                    })
                    .ToDictionaryAsync(x => x.Periode, x => x.Nombre);
                
                // Compléter avec les mois sans données
                for (int i = 0; i < 12; i++)
                {
                    var date = dateDebut.AddMonths(i);
                    var periode = $"{GetNomMois(date.Month)} {date.Year}";
                    
                    if (!resultat.ContainsKey(periode))
                    {
                        resultat[periode] = 0;
                    }
                }
                
                return resultat.OrderBy(m => DateTime.ParseExact($"01/{Array.IndexOf(GetMoisArray(), m.Key.Split(' ')[0]) + 1}/{m.Key.Split(' ')[1]}", "dd/MM/yyyy", null))
                    .ToDictionary(m => m.Key, m => m.Value);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur dans GetMissionsParMoisAsync");
                return new Dictionary<string, int>();
            }
        }
        
        public async Task<Dictionary<string, int>> GetServicesParDomaineAsync(FiltreStatistiques? filtre = null)
        {
            try
            {
                var resultat = await _context.Services
                    .Include(s => s.DomaineSce)
                    .Where(s => s.DomaineSce != null)
                    .GroupBy(s => s.DomaineSce!.LibaDomSce)
                    .Select(g => new { Domaine = g.Key, Count = g.Count() })
                    .OrderByDescending(x => x.Count)
                    .ToDictionaryAsync(x => x.Domaine, x => x.Count);
                
                return resultat;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur dans GetServicesParDomaineAsync");
                // Retourner un dictionnaire vide en cas d'erreur
                return new Dictionary<string, int>();
            }
        }
        #endregion

        #region Statistiques par domaine
        public async Task<ResultatStatistiquesParDomaine> GetStatistiquesParDomaineAsync(FiltreDomaineStatistiques? filtre = null)
        {
            var resultat = new ResultatStatistiquesParDomaine();
            
            try
            {
                // Calculer le nombre total de services
                resultat.TotalServices = await _context.Services.CountAsync();
                
                // Calculer le nombre total de missions
                resultat.TotalMissions = await _context.Missions.CountAsync();
                
                // Récupérer les statistiques par domaine
                var domainesStats = await _context.DomainesService
                    .Select(d => new
                    {
                        d.IdDomSce,
                        d.LibaDomSce,
                        NombreServices = d.Services.Count,
                        NombreMissions = d.Services.SelectMany(s => s.Mission != null ? new[] { s.Mission } : Array.Empty<Mission>()).Distinct().Count()
                    })
                    .OrderByDescending(d => d.NombreServices)
                    .ToListAsync();
                
                foreach (var domaine in domainesStats)
                {
                    var stat = new StatistiqueParDomaine
                    {
                        IdDomaine = domaine.IdDomSce,
                        LibelleDomaine = domaine.LibaDomSce ?? "Non défini",
                        NombreServices = domaine.NombreServices,
                        NombreMissions = domaine.NombreMissions,
                        PourcentageTotal = resultat.TotalServices > 0 
                            ? Math.Round((double)domaine.NombreServices / resultat.TotalServices * 100, 2) 
                            : 0
                    };
                    
                    // Distribution par mois (data des 12 derniers mois)
                    var dateDebut = DateTime.Now.AddMonths(-11);
                    var serviceParMois = await _context.Services
                        .Where(s => s.IdDomSce == domaine.IdDomSce && s.DateDebutSce >= dateDebut)
                        .GroupBy(s => new { Annee = s.DateDebutSce!.Value.Year, Mois = s.DateDebutSce.Value.Month })
                        .Select(g => new
                        {
                            Periode = $"{GetNomMois(g.Key.Mois)} {g.Key.Annee}",
                            Nombre = g.Count()
                        })
                        .ToDictionaryAsync(x => x.Periode, x => x.Nombre);
                    
                    // Compléter avec les mois sans données
                    for (int i = 0; i < 12; i++)
                    {
                        var date = dateDebut.AddMonths(i);
                        var periode = $"{GetNomMois(date.Month)} {date.Year}";
                        
                        if (!serviceParMois.ContainsKey(periode))
                        {
                            serviceParMois[periode] = 0;
                        }
                    }
                    
                    stat.DistributionParMois = serviceParMois.OrderBy(m => DateTime.ParseExact($"01/{Array.IndexOf(GetMoisArray(), m.Key.Split(' ')[0]) + 1}/{m.Key.Split(' ')[1]}", "dd/MM/yyyy", null))
                        .ToDictionary(m => m.Key, m => m.Value);
                    
                    resultat.StatistiquesParDomaine.Add(stat);
                }
                
                return resultat;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur dans GetStatistiquesParDomaineAsync");
                
                // En cas d'erreur, retourner un objet vide
                resultat.TotalServices = 0;
                resultat.TotalMissions = 0;
                
                return resultat;
            }
        }

        public async Task<StatistiqueParDomaine> GetDetailsDomaine(decimal idDomaine, FiltreDomaineStatistiques? filtre = null)
        {
            try
            {
                var domaine = await _context.DomainesService
                    .FirstOrDefaultAsync(d => d.IdDomSce == idDomaine);
                
                if (domaine == null)
                {
                    throw new KeyNotFoundException($"Domaine non trouvé: {idDomaine}");
                }
                
                var statsParDomaine = new StatistiqueParDomaine
                {
                    IdDomaine = domaine.IdDomSce,
                    LibelleDomaine = domaine.LibaDomSce ?? "Non défini"
                };
                
                // Récupérer le nombre de services dans ce domaine
                statsParDomaine.NombreServices = await _context.Services
                    .CountAsync(s => s.IdDomSce == idDomaine);
                
                // Récupérer le nombre de missions associées à ce domaine
                statsParDomaine.NombreMissions = await _context.Services
                    .Where(s => s.IdDomSce == idDomaine)
                    .Select(s => s.IdMission)
                    .Distinct()
                    .CountAsync();
                
                // Calculer le pourcentage sur le total
                var totalServices = await _context.Services.CountAsync();
                statsParDomaine.PourcentageTotal = totalServices > 0
                    ? Math.Round((double)statsParDomaine.NombreServices / totalServices * 100, 2)
                    : 0;
                
                // Distribution par mois (data des 24 derniers mois)
                var dateDebut = DateTime.Now.AddMonths(-23);
                var serviceParMois = await _context.Services
                    .Where(s => s.IdDomSce == idDomaine && s.DateDebutSce >= dateDebut)
                    .GroupBy(s => new { Annee = s.DateDebutSce!.Value.Year, Mois = s.DateDebutSce.Value.Month })
                    .Select(g => new
                    {
                        Periode = $"{GetNomMois(g.Key.Mois)} {g.Key.Annee}",
                        Nombre = g.Count()
                    })
                    .ToDictionaryAsync(x => x.Periode, x => x.Nombre);
                
                // Compléter avec les mois sans données
                for (int i = 0; i < 24; i++)
                {
                    var date = dateDebut.AddMonths(i);
                    var periode = $"{GetNomMois(date.Month)} {date.Year}";
                    
                    if (!serviceParMois.ContainsKey(periode))
                    {
                        serviceParMois[periode] = 0;
                    }
                }
                
                statsParDomaine.DistributionParMois = serviceParMois.OrderBy(m => DateTime.ParseExact($"01/{Array.IndexOf(GetMoisArray(), m.Key.Split(' ')[0]) + 1}/{m.Key.Split(' ')[1]}", "dd/MM/yyyy", null))
                    .ToDictionary(m => m.Key, m => m.Value);
                
                return statsParDomaine;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur dans GetDetailsDomaine");
                
                // En cas d'erreur, retourner un objet vide
                return new StatistiqueParDomaine
                {
                    IdDomaine = idDomaine,
                    LibelleDomaine = "Non trouvé"
                };
            }
        }
        #endregion

        #region Statistiques par service
        public async Task<ResultatStatistiquesParService> GetStatistiquesParServiceAsync(FiltreServiceStatistiques? filtre = null)
        {
            var resultat = new ResultatStatistiquesParService();
            
            try
            {
                // Calculer le nombre total de services
                resultat.TotalServices = await _context.Services.CountAsync();
                
                // Calculer le nombre total de missions
                resultat.TotalMissions = await _context.Missions.CountAsync();
                
                // Calculer la durée totale des missions en minutes
                resultat.DureeTotaleMissions = (int)await _context.Services
                    .Where(s => s.DateDebutSce != null && s.DateFinSce != null)
                    .SumAsync(s => s.NbrMinuteTot ?? 0);
                
                // Récupérer les statistiques par service
                var servicesStats = await _context.Services
                    .Include(s => s.TypeSce)
                    .Where(s => s.TypeSce != null)
                    .GroupBy(s => new { s.TypeSce!.IdTypeSce, s.TypeSce.LibaTypeSce })
                    .Select(g => new
                    {
                        Id = g.Key.IdTypeSce,
                        Libelle = g.Key.LibaTypeSce,
                        NombreMissions = g.Select(s => s.IdMission).Distinct().Count(),
                        DureeTotaleMinutes = g.Sum(s => s.NbrMinuteTot ?? 0)
                    })
                    .OrderByDescending(s => s.DureeTotaleMinutes)
                    .Take(10)
                    .ToListAsync();
                
                foreach (var service in servicesStats)
                {
                    var stat = new StatistiqueParService
                    {
                        IdService = decimal.Parse(service.Id),
                        LibelleService = service.Libelle ?? "Non défini",
                        NombreMissions = service.NombreMissions,
                        DureeTotaleMinutes = (int)service.DureeTotaleMinutes,
                        PourcentageTotal = resultat.DureeTotaleMissions > 0 
                            ? Math.Round((double)service.DureeTotaleMinutes / resultat.DureeTotaleMissions * 100, 2) 
                            : 0
                    };
                    
                    // Distribution par mois (data des 12 derniers mois)
                    var dateDebut = DateTime.Now.AddMonths(-11);
                    var serviceParMois = await _context.Services
                        .Where(s => s.IdTypeSce == service.Id && s.DateDebutSce >= dateDebut)
                        .GroupBy(s => new { Annee = s.DateDebutSce!.Value.Year, Mois = s.DateDebutSce.Value.Month })
                        .Select(g => new
                        {
                            Periode = $"{GetNomMois(g.Key.Mois)} {g.Key.Annee}",
                            Nombre = g.Count()
                        })
                        .ToDictionaryAsync(x => x.Periode, x => x.Nombre);
                    
                    // Compléter avec les mois sans données
                    for (int i = 0; i < 12; i++)
                    {
                        var date = dateDebut.AddMonths(i);
                        var periode = $"{GetNomMois(date.Month)} {date.Year}";
                        
                        if (!serviceParMois.ContainsKey(periode))
                        {
                            serviceParMois[periode] = 0;
                        }
                    }
                    
                    stat.DistributionParMois = serviceParMois.OrderBy(m => DateTime.ParseExact($"01/{Array.IndexOf(GetMoisArray(), m.Key.Split(' ')[0]) + 1}/{m.Key.Split(' ')[1]}", "dd/MM/yyyy", null))
                        .ToDictionary(m => m.Key, m => m.Value);
                    
                    resultat.StatistiquesParService.Add(stat);
                }
                
                return resultat;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur dans GetStatistiquesParServiceAsync");
                
                // En cas d'erreur, retourner un objet vide
                resultat.TotalServices = 0;
                resultat.TotalMissions = 0;
                resultat.DureeTotaleMissions = 0;
                
                return resultat;
            }
        }

        public async Task<StatistiqueParService> GetDetailsService(decimal idService, FiltreServiceStatistiques? filtre = null)
        {
            try
            {
                var typeService = await _context.TypesService
                    .FirstOrDefaultAsync(t => t.IdTypeSce == idService.ToString());
                
                if (typeService == null)
                {
                    throw new KeyNotFoundException($"Type de service non trouvé: {idService}");
                }
                
                var statsParService = new StatistiqueParService
                {
                    IdService = decimal.Parse(typeService.IdTypeSce),
                    LibelleService = typeService.LibaTypeSce ?? "Non défini"
                };
                
                // Récupérer le nombre de missions pour ce type de service
                statsParService.NombreMissions = await _context.Services
                    .Where(s => s.IdTypeSce == typeService.IdTypeSce)
                    .Select(s => s.IdMission)
                    .Distinct()
                    .CountAsync();
                
                // Récupérer la durée totale des services de ce type
                statsParService.DureeTotaleMinutes = (int)await _context.Services
                    .Where(s => s.IdTypeSce == typeService.IdTypeSce && s.NbrMinuteTot != null)
                    .SumAsync(s => s.NbrMinuteTot ?? 0);
                
                // Calculer le pourcentage sur le total
                var dureeTotale = await _context.Services
                    .Where(s => s.NbrMinuteTot != null)
                    .SumAsync(s => s.NbrMinuteTot ?? 0);
                
                statsParService.PourcentageTotal = dureeTotale > 0
                    ? Math.Round((double)statsParService.DureeTotaleMinutes / (double)dureeTotale * 100, 2)
                    : 0;
                
                // Distribution par mois (data des 24 derniers mois)
                var dateDebut = DateTime.Now.AddMonths(-23);
                var serviceParMois = await _context.Services
                    .Where(s => s.IdTypeSce == typeService.IdTypeSce && s.DateDebutSce >= dateDebut)
                    .GroupBy(s => new { Annee = s.DateDebutSce!.Value.Year, Mois = s.DateDebutSce.Value.Month })
                    .Select(g => new
                    {
                        Periode = $"{GetNomMois(g.Key.Mois)} {g.Key.Annee}",
                        Nombre = g.Count()
                    })
                    .ToDictionaryAsync(x => x.Periode, x => x.Nombre);
                
                // Compléter avec les mois sans données
                for (int i = 0; i < 24; i++)
                {
                    var date = dateDebut.AddMonths(i);
                    var periode = $"{GetNomMois(date.Month)} {date.Year}";
                    
                    if (!serviceParMois.ContainsKey(periode))
                    {
                        serviceParMois[periode] = 0;
                    }
                }
                
                statsParService.DistributionParMois = serviceParMois.OrderBy(m => DateTime.ParseExact($"01/{Array.IndexOf(GetMoisArray(), m.Key.Split(' ')[0]) + 1}/{m.Key.Split(' ')[1]}", "dd/MM/yyyy", null))
                    .ToDictionary(m => m.Key, m => m.Value);
                
                return statsParService;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur dans GetDetailsService");
                
                // En cas d'erreur, retourner un objet vide
                return new StatistiqueParService
                {
                    IdService = idService,
                    LibelleService = "Non trouvé"
                };
            }
        }
        #endregion

        #region Statistiques par type
        public async Task<ResultatStatistiquesParType> GetStatistiquesParTypeAsync(FiltreStatistiques? filtre = null)
        {
            var resultat = new ResultatStatistiquesParType();
            
            try
            {
                // Calculer le nombre total de services
                resultat.TotalServices = await _context.Services.CountAsync();
                
                // Calculer le nombre total de types de services
                resultat.TotalTypesServices = await _context.TypesService.CountAsync();
                
                // Récupérer les statistiques par type de service
                var typesStats = await _context.TypesService
                    .GroupJoin(_context.Services,
                        t => t.IdTypeSce,
                        s => s.IdTypeSce,
                        (type, services) => new
                        {
                            type.IdTypeSce,
                            type.LibaTypeSce,
                            Services = services.ToList()
                        })
                    .Select(g => new
                    {
                        Id = g.IdTypeSce,
                        Libelle = g.LibaTypeSce,
                        NombreServices = g.Services.Count,
                        NombreMissions = g.Services.Select(s => s.IdMission).Distinct().Count()
                    })
                    .OrderByDescending(t => t.NombreServices)
                    .Take(10)
                    .ToListAsync();
                
                foreach (var type in typesStats)
                {
                    var stat = new StatistiqueParType
                    {
                        IdType = type.Id,
                        LibelleType = type.Libelle ?? "Non défini",
                        NombreServices = type.NombreServices,
                        NombreMissions = type.NombreMissions,
                        PourcentageTotal = resultat.TotalServices > 0 
                            ? Math.Round((double)type.NombreServices / resultat.TotalServices * 100, 2) 
                            : 0
                    };
                    
                    resultat.StatistiquesParType.Add(stat);
                }
                
                return resultat;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur dans GetStatistiquesParTypeAsync");
                
                // En cas d'erreur, retourner un objet vide
                resultat.TotalServices = 0;
                resultat.TotalTypesServices = 0;
                
                return resultat;
            }
        }

        public async Task<StatistiqueParType> GetDetailsType(string idType, FiltreStatistiques? filtre = null)
        {
            try
            {
                var type = await _context.TypesService
                    .FirstOrDefaultAsync(t => t.IdTypeSce == idType);
                
                if (type == null)
                {
                    throw new KeyNotFoundException($"Type de service non trouvé: {idType}");
                }
                
                var statsParType = new StatistiqueParType
                {
                    IdType = type.IdTypeSce,
                    LibelleType = type.LibaTypeSce ?? "Non défini"
                };
                
                // Récupérer le nombre de services pour ce type
                statsParType.NombreServices = await _context.Services
                    .CountAsync(s => s.IdTypeSce == idType);
                
                // Récupérer le nombre de missions associées à ce type
                statsParType.NombreMissions = await _context.Services
                    .Where(s => s.IdTypeSce == idType)
                    .Select(s => s.IdMission)
                    .Distinct()
                    .CountAsync();
                
                // Calculer le pourcentage sur le total
                var totalServices = await _context.Services.CountAsync();
                statsParType.PourcentageTotal = totalServices > 0
                    ? Math.Round((double)statsParType.NombreServices / totalServices * 100, 2)
                    : 0;
                
                // Distribution par mois (data des 24 derniers mois)
                var dateDebut = DateTime.Now.AddMonths(-23);
                var serviceParMois = await _context.Services
                    .Where(s => s.IdTypeSce == idType && s.DateDebutSce >= dateDebut)
                    .GroupBy(s => new { Annee = s.DateDebutSce!.Value.Year, Mois = s.DateDebutSce.Value.Month })
                    .Select(g => new
                    {
                        Periode = $"{GetNomMois(g.Key.Mois)} {g.Key.Annee}",
                        Nombre = g.Count()
                    })
                    .ToDictionaryAsync(x => x.Periode, x => x.Nombre);
                
                // Compléter avec les mois sans données
                for (int i = 0; i < 24; i++)
                {
                    var date = dateDebut.AddMonths(i);
                    var periode = $"{GetNomMois(date.Month)} {date.Year}";
                    
                    if (!serviceParMois.ContainsKey(periode))
                    {
                        serviceParMois[periode] = 0;
                    }
                }
                
                statsParType.DistributionParMois = serviceParMois.OrderBy(m => DateTime.ParseExact($"01/{Array.IndexOf(GetMoisArray(), m.Key.Split(' ')[0]) + 1}/{m.Key.Split(' ')[1]}", "dd/MM/yyyy", null))
                    .ToDictionary(m => m.Key, m => m.Value);
                
                return statsParType;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur dans GetDetailsType");
                
                // En cas d'erreur, retourner un objet vide
                return new StatistiqueParType
                {
                    IdType = idType,
                    LibelleType = "Non trouvé"
                };
            }
        }
        #endregion

        #region Statistiques par mission
        public async Task<ResultatStatistiquesParMission> GetStatistiquesParMissionAsync(FiltreMissionStatistiques? filtre = null)
        {
            var resultat = new ResultatStatistiquesParMission();
            
            try
            {
                // Calculer le nombre total de missions
                resultat.TotalMissions = await _context.Missions.CountAsync();
                
                // Calculer le nombre total de services
                resultat.TotalServices = await _context.Services.CountAsync();
                
                // Calculer le nombre total d'employés
                resultat.TotalEmployes = await _context.MissionEmployes
                    .Select(me => me.IdEmp)
                    .Distinct()
                    .CountAsync();
                
                // Calculer le nombre total de véhicules
                resultat.TotalVehicules = await _context.MissionVehicules
                    .Select(mv => mv.IdVeh)
                    .Distinct()
                    .CountAsync();
                
                // Récupérer les dernières missions
                var missions = await _context.Missions
                    .Where(m => m.DateDebutMission != null)
                    .OrderByDescending(m => m.DateDebutMission)
                    .Take(10)
                    .ToListAsync();
                
                foreach (var mission in missions)
                {
                    var statMission = new StatistiqueParMission
                    {
                        IdMission = mission.IdMission,
                        ObjetMission = mission.ObjetMission ?? "Mission sans objet",
                        DateDebut = mission.DateDebutMission,
                        DateFin = mission.DateFinMission
                    };
                    
                    // Calculer la durée totale en minutes
                    if (mission.DateDebutMission != null && mission.DateFinMission != null)
                    {
                        statMission.DureeTotaleMinutes = (int)(mission.DateFinMission.Value - mission.DateDebutMission.Value).TotalMinutes;
                    }
                    
                    // Récupérer le nombre de services associés
                    statMission.NombreServices = await _context.Services
                        .CountAsync(s => s.IdMission == mission.IdMission);
                    
                    // Récupérer le nombre d'employés associés
                    statMission.NombreEmployes = await _context.MissionEmployes
                        .CountAsync(me => me.IdMission == mission.IdMission);
                    
                    // Récupérer le nombre de véhicules associés
                    statMission.NombreVehicules = await _context.MissionVehicules
                        .CountAsync(mv => mv.IdMission == mission.IdMission);
                    
                    resultat.StatistiquesParMission.Add(statMission);
                }
                
                // Distribution des missions par mois
                var dateDebut = DateTime.Now.AddMonths(-11);
                var missionsParMois = await _context.Missions
                    .Where(m => m.DateDebutMission >= dateDebut)
                    .GroupBy(m => new { Annee = m.DateDebutMission!.Value.Year, Mois = m.DateDebutMission.Value.Month })
                    .Select(g => new
                    {
                        Periode = $"{GetNomMois(g.Key.Mois)}",
                        Nombre = g.Count()
                    })
                    .ToDictionaryAsync(x => x.Periode, x => x.Nombre);
                
                // Compléter avec les mois sans données
                for (int i = 0; i < 12; i++)
                {
                    var date = dateDebut.AddMonths(i);
                    var nomMois = GetNomMois(date.Month);
                    
                    if (!missionsParMois.ContainsKey(nomMois))
                    {
                        missionsParMois[nomMois] = 0;
                    }
                }
                
                resultat.MissionsParMois = missionsParMois.OrderBy(m => Array.IndexOf(GetMoisArray(), m.Key))
                    .ToDictionary(m => m.Key, m => m.Value);
                
                return resultat;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur dans GetStatistiquesParMissionAsync");
                
                // En cas d'erreur, retourner un objet vide
                resultat.TotalMissions = 0;
                resultat.TotalServices = 0;
                resultat.TotalEmployes = 0;
                resultat.TotalVehicules = 0;
                
                // Dictionnaire vide pour les missions par mois
                resultat.MissionsParMois = new Dictionary<string, int>();
                
                return resultat;
            }
        }

        public async Task<StatistiqueParMission> GetDetailsMission(decimal idMission, FiltreMissionStatistiques? filtre = null)
        {
            try
            {
                var mission = await _context.Missions
                    .FirstOrDefaultAsync(m => m.IdMission == idMission);
                
                if (mission == null)
                {
                    throw new KeyNotFoundException($"Mission non trouvée: {idMission}");
                }
                
                var statsMission = new StatistiqueParMission
                {
                    IdMission = mission.IdMission,
                    ObjetMission = mission.ObjetMission ?? "Mission sans objet",
                    DateDebut = mission.DateDebutMission,
                    DateFin = mission.DateFinMission
                };
                
                // Calculer la durée totale en minutes
                if (mission.DateDebutMission != null && mission.DateFinMission != null)
                {
                    statsMission.DureeTotaleMinutes = (int)(mission.DateFinMission.Value - mission.DateDebutMission.Value).TotalMinutes;
                }
                
                // Récupérer le nombre de services associés
                statsMission.NombreServices = await _context.Services
                    .CountAsync(s => s.IdMission == mission.IdMission);
                
                // Récupérer le nombre d'employés associés
                statsMission.NombreEmployes = await _context.MissionEmployes
                    .CountAsync(me => me.IdMission == mission.IdMission);
                
                // Récupérer le nombre de véhicules associés
                statsMission.NombreVehicules = await _context.MissionVehicules
                    .CountAsync(mv => mv.IdMission == mission.IdMission);
                
                // Distribution par type de service
                var typeServiceDistribution = await _context.Services
                    .Where(s => s.IdMission == mission.IdMission && s.TypeSce != null)
                    .GroupBy(s => s.TypeSce!.LibaTypeSce)
                    .Select(g => new
                    {
                        Type = g.Key,
                        Nombre = g.Count()
                    })
                    .ToDictionaryAsync(x => x.Type ?? "Non défini", x => x.Nombre);
                
                statsMission.DistributionParTypeService = typeServiceDistribution;
                
                // Distribution par grade d'employé
                var gradeDistribution = await _context.MissionEmployes
                    .Where(me => me.IdMission == mission.IdMission && me.GradeEmp != null)
                    .GroupBy(me => me.GradeEmp)
                    .Select(g => new
                    {
                        Grade = g.Key,
                        Nombre = g.Count()
                    })
                    .ToDictionaryAsync(x => x.Grade ?? "Non défini", x => x.Nombre);
                
                statsMission.DistributionParGrade = gradeDistribution;
                
                return statsMission;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur dans GetDetailsMission");
                
                // En cas d'erreur, retourner un objet vide
                return new StatistiqueParMission
                {
                    IdMission = idMission,
                    ObjetMission = "Non trouvé"
                };
            }
        }

        public async Task<Dictionary<string, int>> GetMissionsParCategorieAsync(FiltreStatistiques? filtre = null)
        {
            try
            {
                var resultat = await _context.Missions
                    .Include(m => m.CategorieMission)
                    .Where(m => m.CategorieMission != null)
                    .GroupBy(m => m.CategorieMission!.LibaCategMiss)
                    .Select(g => new { Categorie = g.Key, Count = g.Count() })
                    .OrderByDescending(x => x.Count)
                    .ToDictionaryAsync(x => x.Categorie ?? "Non catégorisée", x => x.Count);
                
                return resultat;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur dans GetMissionsParCategorieAsync");
                
                // Retourner un dictionnaire vide en cas d'erreur
                return new Dictionary<string, int>();
            }
        }
        #endregion

        #region Méthodes utilitaires
        private string GetNomMois(int mois)
        {
            string[] noms = GetMoisArray();
            if (mois >= 1 && mois <= 12)
            {
                return noms[mois - 1];
            }
            return "Mois inconnu";
        }
        
        private string[] GetMoisArray()
        {
            return new string[] { "Jan", "Fév", "Mar", "Avr", "Mai", "Juin", "Juil", "Août", "Sept", "Oct", "Nov", "Déc" };
        }
        #endregion
    }
}