using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StatistiquesDashboard.Data;
using StatistiquesDashboard.Models.ViewModels;
using StatistiquesDashboard.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StatistiquesDashboard.Pages.Stats
{
    public class StatistiqueTypeModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly IStatsService _statsService;

        public ResultatStatistiquesParType Resultat { get; set; } = new ResultatStatistiquesParType();
        public List<string> Classes { get; set; } = new List<string>();
        
        // Dictionnaire pour stocker la relation entre les types et les classes
        private Dictionary<string, string> _typeClassMapping = new Dictionary<string, string>();

        public StatistiqueTypeModel(ApplicationDbContext context, IStatsService statsService)
        {
            _context = context;
            _statsService = statsService;
        }

        public async Task<IActionResult> OnGetAsync()
        {
            try
            {
                // Récupérer les statistiques par type
                Resultat = await _statsService.GetStatistiquesParTypeAsync();
                
                // Récupérer la liste des classes pour le filtre et pour le mapping
                var classes = await _context.ClassesService.ToListAsync();
                Classes = classes.Select(c => c.LibComplete).OrderBy(l => l).ToList();
                
                // Construire le mapping entre les types et les classes
                var types = await _context.TypesService
                    .Include(t => t.ClassSce)
                    .ToListAsync();
                    
                foreach (var type in types)
                {
                    if (type.ClassSce != null)
                    {
                        _typeClassMapping[type.IdTypeSce] = type.ClassSce.LibComplete;
                    }
                }
                
                return Page();
            }
            catch (Exception ex)
            {
                // Gérer l'erreur (par exemple, en l'enregistrant) et afficher un message convivial
                ModelState.AddModelError(string.Empty, "Une erreur s'est produite lors du chargement des statistiques par type.");
                Console.WriteLine($"Erreur: {ex.Message}");
                
                // Initialiser un résultat vide pour éviter les exceptions null
                Resultat = new ResultatStatistiquesParType();
                return Page();
            }
        }
        
        // Méthode pour obtenir la classe d'un type
        public string GetClasseForType(string idType)
        {
            if (_typeClassMapping.ContainsKey(idType))
            {
                return _typeClassMapping[idType];
            }
            return "N/A";
        }

        // Cette méthode peut être utilisée pour récupérer les détails d'un type spécifique via AJAX
        public async Task<IActionResult> OnGetDetailTypeAsync(string idType)
        {
            try
            {
                var detailsType = await _statsService.GetDetailsType(idType);
                return new JsonResult(detailsType);
            }
            catch (Exception ex)
            {
                return new JsonResult(new { error = ex.Message });
            }
        }
    }
}