using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StatistiquesDashboard.Models
{
    [Table("MISSION_VEHICULE")]
    public class MissionVehicule
    {
        [Key]
        [Column("ID_MISSION_VEH")]
        public decimal IdMissionVeh { get; set; }
        
        [Column("ID_VEH")]
        public decimal IdVeh { get; set; }
        
        [Column("ID_MISSION")]
        public decimal IdMission { get; set; }
        
        [Column("DISTANCE_PARCOURU")]
        public decimal? DistanceParcouru { get; set; }
        
        [Column("INFO_PLUS_SCE_VEH")]
        public string? InfoPlusSceVeh { get; set; }
        
        [Column("MATMILVEH")]
        public string? MatMilVeh { get; set; }
        
        [Column("MATCIVVEH")]
        public string? MatCivVeh { get; set; }
        
        [Column("OLD_NB_KLM")]
        public decimal? OldNbKlm { get; set; }
        
        [Column("NEW_NB_KLM")]
        public decimal? NewNbKlm { get; set; }
        
        [Column("CREATED_ON")]
        public DateTime? CreatedOn { get; set; }
        
        // Navigation properties
        [ForeignKey("IdMission")]
        public virtual Mission? Mission { get; set; }
    }
}