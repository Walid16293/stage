using Microsoft.AspNetCore.Mvc;
using StatistiquesDashboard.Services;
using StatistiquesDashboard.Models.ViewModels;

namespace StatistiquesDashboard.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatsController : ControllerBase
    {
        private readonly IStatsService _statsService;
        private readonly ILogger<StatsController> _logger;

        public StatsController(IStatsService statsService, ILogger<StatsController> logger)
        {
            _statsService = statsService;
            _logger = logger;
        }

        [HttpGet("domaines")]
        public async Task<IActionResult> GetStatistiquesDomaines([FromQuery] FiltreDomaineStatistiques filtre)
        {
            try
            {
                var resultat = await _statsService.GetStatistiquesParDomaineAsync(filtre);
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors de la récupération des statistiques par domaine");
                return StatusCode(500, "Une erreur est survenue lors de la récupération des statistiques");
            }
        }

        [HttpGet("domaines/{id}")]
        public async Task<IActionResult> GetDetailsDomaine(decimal id, [FromQuery] FiltreDomaineStatistiques filtre)
        {
            try
            {
                var resultat = await _statsService.GetDetailsDomaine(id, filtre);
                if (resultat.LibelleDomaine == "Non trouvé")
                {
                    return NotFound($"Domaine avec ID {id} non trouvé");
                }
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erreur lors de la récupération des détails du domaine {id}");
                return StatusCode(500, "Une erreur est survenue lors de la récupération des détails du domaine");
            }
        }

        [HttpGet("services")]
        public async Task<IActionResult> GetStatistiquesServices([FromQuery] FiltreServiceStatistiques filtre)
        {
            try
            {
                var resultat = await _statsService.GetStatistiquesParServiceAsync(filtre);
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors de la récupération des statistiques par service");
                return StatusCode(500, "Une erreur est survenue lors de la récupération des statistiques");
            }
        }

        [HttpGet("services/{id}")]
        public async Task<IActionResult> GetDetailsService(decimal id, [FromQuery] FiltreServiceStatistiques filtre)
        {
            try
            {
                var resultat = await _statsService.GetDetailsService(id, filtre);
                if (resultat.LibelleService == "Non trouvé")
                {
                    return NotFound($"Service avec ID {id} non trouvé");
                }
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erreur lors de la récupération des détails du service {id}");
                return StatusCode(500, "Une erreur est survenue lors de la récupération des détails du service");
            }
        }

        [HttpGet("types")]
        public async Task<IActionResult> GetStatistiquesTypes()
        {
            try
            {
                var resultat = await _statsService.GetStatistiquesParTypeAsync();
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors de la récupération des statistiques par type");
                return StatusCode(500, "Une erreur est survenue lors de la récupération des statistiques");
            }
        }

        [HttpGet("types/{id}")]
        public async Task<IActionResult> GetDetailsType(string id)
        {
            try
            {
                var resultat = await _statsService.GetDetailsType(id);
                if (resultat.LibelleType == "Non trouvé")
                {
                    return NotFound($"Type avec ID {id} non trouvé");
                }
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erreur lors de la récupération des détails du type {id}");
                return StatusCode(500, "Une erreur est survenue lors de la récupération des détails du type");
            }
        }

        [HttpGet("missions")]
        public async Task<IActionResult> GetStatistiquesMissions()
        {
            try
            {
                var resultat = await _statsService.GetStatistiquesParMissionAsync();
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors de la récupération des statistiques par mission");
                return StatusCode(500, "Une erreur est survenue lors de la récupération des statistiques");
            }
        }

        [HttpGet("missions/{id}")]
        public async Task<IActionResult> GetDetailsMission(decimal id)
        {
            try
            {
                var resultat = await _statsService.GetDetailsMission(id);
                if (resultat.ObjetMission == "Non trouvé")
                {
                    return NotFound($"Mission avec ID {id} non trouvée");
                }
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erreur lors de la récupération des détails de la mission {id}");
                return StatusCode(500, "Une erreur est survenue lors de la récupération des détails de la mission");
            }
        }

        [HttpGet("repartition/services-par-domaine")]
        public async Task<IActionResult> GetServicesParDomaine()
        {
            try
            {
                var resultat = await _statsService.GetServicesParDomaineAsync();
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors de la récupération de la répartition des services par domaine");
                return StatusCode(500, "Une erreur est survenue lors de la récupération des statistiques");
            }
        }

        [HttpGet("repartition/missions-par-categorie")]
        public async Task<IActionResult> GetMissionsParCategorie()
        {
            try
            {
                var resultat = await _statsService.GetMissionsParCategorieAsync();
                return Ok(resultat);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors de la récupération de la répartition des missions par catégorie");
                return StatusCode(500, "Une erreur est survenue lors de la récupération des statistiques");
            }
        }
    }
}