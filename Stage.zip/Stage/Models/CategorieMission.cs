using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StatistiquesDashboard.Models
{
    [Table("CATEGORIE_MISSION")]
    public class CategorieMission
    {
        [Key]
        [Column("ID_CATEG_MISS")]
        public decimal IdCategMiss { get; set; }
        
        [Column("LIBA_CATEG_MISS")]
        public string? LibaCategMiss { get; set; }
        
        // Navigation property
        public virtual ICollection<Mission> Missions { get; set; } = new List<Mission>();
    }
}