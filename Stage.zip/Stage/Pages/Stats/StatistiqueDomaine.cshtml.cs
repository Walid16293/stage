using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using StatistiquesDashboard.Data;
using StatistiquesDashboard.Models.ViewModels;
using StatistiquesDashboard.Services;
using System;
using System.Threading.Tasks;

namespace StatistiquesDashboard.Pages.Stats
{
    public class StatistiqueDomaineModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly IStatsService _statsService;

        public ResultatStatistiquesParDomaine Resultat { get; set; } = new ResultatStatistiquesParDomaine();

        public StatistiqueDomaineModel(ApplicationDbContext context, IStatsService statsService)
        {
            _context = context;
            _statsService = statsService;
        }

        public async Task<IActionResult> OnGetAsync()
        {
            try
            {
                Resultat = await _statsService.GetStatistiquesParDomaineAsync();
                return Page();
            }
            catch (Exception ex)
            {
                // Gérer l'erreur (par exemple, en l'enregistrant) et afficher un message convivial
                ModelState.AddModelError(string.Empty, "Une erreur s'est produite lors du chargement des statistiques par domaine.");
                Console.WriteLine($"Erreur: {ex.Message}");
                
                // Initialiser un résultat vide pour éviter les exceptions null
                Resultat = new ResultatStatistiquesParDomaine();
                return Page();
            }
        }

        // Cette méthode peut être utilisée pour récupérer les détails d'un domaine spécifique via AJAX
        public async Task<IActionResult> OnGetDetailDomaineAsync(int idDomaine)
        {
            try
            {
                var detailsDomaine = await _statsService.GetDetailsDomaine(idDomaine);
                return new JsonResult(detailsDomaine);
            }
            catch (Exception ex)
            {
                return new JsonResult(new { error = ex.Message });
            }
        }
    }
}