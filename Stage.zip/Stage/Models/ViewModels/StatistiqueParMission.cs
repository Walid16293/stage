namespace StatistiquesDashboard.Models.ViewModels
{
    public class StatistiqueParMission
    {
        public decimal IdMission { get; set; }
        public string ObjetMission { get; set; } = string.Empty;
        public DateTime? DateDebut { get; set; }
        public DateTime? DateFin { get; set; }
        public int DureeTotaleMinutes { get; set; }
        public int NombreServices { get; set; }
        public int NombreEmployes { get; set; }
        public int NombreVehicules { get; set; }
        public Dictionary<string, int> DistributionParTypeService { get; set; } = new Dictionary<string, int>();
        public Dictionary<string, int> DistributionParGrade { get; set; } = new Dictionary<string, int>();
        
        // Propriétés pour les graphiques
        public List<string> LabelsTypesService => DistributionParTypeService.Keys.ToList();
        public List<int> DonneesTypesService => DistributionParTypeService.Values.ToList();
        public List<string> LabelsGrades => DistributionParGrade.Keys.ToList();
        public List<int> DonneesGrades => DistributionParGrade.Values.ToList();
        public string CouleurPrincipale { get; set; } = "#f6c23e";
        public List<string> PaletteDeCouleurs { get; set; } = new List<string>
        {
            "#f6c23e", "#4e73df", "#1cc88a", "#36b9cc", "#e74a3b", "#858796",
            "#5a5c69", "#476adc", "#17a673", "#2c9faf", "#f5b835", "#e02d1b"
        };
        
        // Propriétés calculées
        public string DureeTotaleFormatee => FormatDuree(DureeTotaleMinutes);
        public string PeriodeFormatee => FormatPeriode(DateDebut, DateFin);
        
        private string FormatDuree(int minutes)
        {
            int heures = minutes / 60;
            int minutesRestantes = minutes % 60;
            return $"{heures}h {minutesRestantes}min";
        }
        
        private string FormatPeriode(DateTime? debut, DateTime? fin)
        {
            if (debut == null || fin == null)
                return "Période non définie";
                
            if (debut.Value.Date == fin.Value.Date)
                return $"Le {debut.Value.ToString("dd/MM/yyyy")}";
                
            return $"Du {debut.Value.ToString("dd/MM/yyyy")} au {fin.Value.ToString("dd/MM/yyyy")}";
        }
    }
    
    public class ResultatStatistiquesParMission
    {
        public int TotalMissions { get; set; }
        public int TotalServices { get; set; }
        public int TotalEmployes { get; set; }
        public int TotalVehicules { get; set; }
        public Dictionary<string, int> MissionsParMois { get; set; } = new Dictionary<string, int>();
        public List<StatistiqueParMission> StatistiquesParMission { get; set; } = new List<StatistiqueParMission>();
        
        // Propriétés pour les graphiques globaux
        public List<string> LabelsMois => MissionsParMois.Keys.ToList();
        public List<int> NombreMissionsParMois => MissionsParMois.Values.ToList();
        public List<string> CouleursGraphique => new List<string>
        {
            "#f6c23e", "#4e73df", "#1cc88a", "#36b9cc", "#e74a3b", "#858796",
            "#5a5c69", "#476adc", "#17a673", "#2c9faf", "#f5b835", "#e02d1b"
        };
    }
}