using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StatistiquesDashboard.Models
{
    [Table("MISSION")]
    public class Mission
    {
        [Key]
        [Column("ID_MISSION")]
        public decimal IdMission { get; set; }
        
        [Column("OBJET_MISSION")]
        public string? ObjetMission { get; set; }
        
        [Column("DATE_DEBUT_MISSION")]
        public DateTime? DateDebutMission { get; set; }
        
        [Column("DATE_FIN_MISSION")]
        public DateTime? DateFinMission { get; set; }
        
        [Column("ID_CATEG_MISS")]
        public decimal? IdCategMiss { get; set; }
        
        [Column("CREATED_ON")]
        public DateTime? CreatedOn { get; set; }
        
        [Column("CREATED_BY")]
        public string? CreatedBy { get; set; }
        
        [Column("VALIDE")]
        public decimal? Valide { get; set; }
        
        [Column("ISEXECUTED")]
        public string? IsExecuted { get; set; }
        
        [Column("ETAPE_MISSION")]
        public decimal? EtapeMission { get; set; }
        
        // Navigation properties
        [ForeignKey("IdCategMiss")]
        public virtual CategorieMission? CategorieMission { get; set; }
        
        public virtual ICollection<Service> Services { get; set; } = new List<Service>();
        public virtual ICollection<MissionEmploye> MissionEmployes { get; set; } = new List<MissionEmploye>();
        public virtual ICollection<MissionVehicule> MissionVehicules { get; set; } = new List<MissionVehicule>();
    }
}