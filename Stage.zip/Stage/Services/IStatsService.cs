using StatistiquesDashboard.Models.ViewModels;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace StatistiquesDashboard.Services
{
    public interface IStatsService
    {
        // Statistiques générales
        Task<Dictionary<string, int>> GetServicesParDomaineAsync(FiltreStatistiques? filtre = null);
        Task<Dictionary<string, int>> GetMissionsParCategorieAsync(FiltreStatistiques? filtre = null);
        Task<Dictionary<string, int>> GetMissionsParMoisAsync(FiltreStatistiques? filtre = null);
        
        // Statistiques par domaine
        Task<ResultatStatistiquesParDomaine> GetStatistiquesParDomaineAsync(FiltreDomaineStatistiques? filtre = null);
        Task<StatistiqueParDomaine> GetDetailsDomaine(decimal idDomaine, FiltreDomaineStatistiques? filtre = null);
        
        // Statistiques par service
        Task<ResultatStatistiquesParService> GetStatistiquesParServiceAsync(FiltreServiceStatistiques? filtre = null);
        Task<StatistiqueParService> GetDetailsService(decimal idService, FiltreServiceStatistiques? filtre = null);
        
        // Statistiques par type
        Task<ResultatStatistiquesParType> GetStatistiquesParTypeAsync(FiltreStatistiques? filtre = null);
        Task<StatistiqueParType> GetDetailsType(string idType, FiltreStatistiques? filtre = null);
        
        // Statistiques par mission
        Task<ResultatStatistiquesParMission> GetStatistiquesParMissionAsync(FiltreMissionStatistiques? filtre = null);
        Task<StatistiqueParMission> GetDetailsMission(decimal idMission, FiltreMissionStatistiques? filtre = null);
    }
}