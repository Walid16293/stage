namespace StatistiquesDashboard.Models.ViewModels
{
    public class StatistiqueParService
    {
        public decimal IdService { get; set; }
        public string LibelleService { get; set; } = string.Empty;
        public int NombreMissions { get; set; }
        public int DureeTotaleMinutes { get; set; }
        public double PourcentageTotal { get; set; }
        public Dictionary<string, int> DistributionParMois { get; set; } = new Dictionary<string, int>();
        
        // Propriétés pour les graphiques
        public List<string> LabelsGraphique => DistributionParMois.Keys.ToList();
        public List<int> DonneesGraphique => DistributionParMois.Values.ToList();
        public string CouleurPrincipale { get; set; } = "#36b9cc";
        public List<string> PaletteDeCouleurs { get; set; } = new List<string>
        {
            "#36b9cc", "#4e73df", "#1cc88a", "#f6c23e", "#e74a3b", "#858796",
            "#5a5c69", "#476adc", "#17a673", "#2c9faf", "#f5b835", "#e02d1b"
        };
        
        // Propriétés calculées
        public string DureeTotaleFormatee => FormatDuree(DureeTotaleMinutes);
        
        private string FormatDuree(int minutes)
        {
            int heures = minutes / 60;
            int minutesRestantes = minutes % 60;
            return $"{heures}h {minutesRestantes}min";
        }
    }
    
    public class ResultatStatistiquesParService
    {
        public int TotalServices { get; set; }
        public int TotalMissions { get; set; }
        public int DureeTotaleMissions { get; set; }
        public List<StatistiqueParService> StatistiquesParService { get; set; } = new List<StatistiqueParService>();
        
        // Propriétés pour les graphiques globaux
        public List<string> LabelsServices => StatistiquesParService.Select(s => s.LibelleService).ToList();
        public List<int> NombreMissionsParService => StatistiquesParService.Select(s => s.NombreMissions).ToList();
        public List<int> DureeParService => StatistiquesParService.Select(s => s.DureeTotaleMinutes).ToList();
        public List<double> PourcentagesParService => StatistiquesParService.Select(s => s.PourcentageTotal).ToList();
        public List<string> CouleursGraphique => new List<string>
        {
            "#36b9cc", "#4e73df", "#1cc88a", "#f6c23e", "#e74a3b", "#858796",
            "#5a5c69", "#476adc", "#17a673", "#2c9faf", "#f5b835", "#e02d1b"
        };
        
        // Propriétés calculées
        public string DureeTotaleFormatee => FormatDuree(DureeTotaleMissions);
        
        private string FormatDuree(int minutes)
        {
            int heures = minutes / 60;
            int minutesRestantes = minutes % 60;
            return $"{heures}h {minutesRestantes}min";
        }
    }
}